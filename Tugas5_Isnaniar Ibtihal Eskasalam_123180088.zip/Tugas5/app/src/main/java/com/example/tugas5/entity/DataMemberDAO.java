package com.example.tugas5.entity;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao

public interface DataMemberDAO {
    @Insert
    Long insertData(DataMember dataMember);

    @Query("Select * from member_db")
    List<DataMember> getData();

    @Update
    int updateData(DataMember item);

    @Delete
    void deleteData(DataMember item);
}
