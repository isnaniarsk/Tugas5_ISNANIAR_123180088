package com.example.tugas5.view;

import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tugas5.R;
import com.example.tugas5.entity.AppDatabase;
import com.example.tugas5.entity.DataMember;

import java.util.List;

public class MainActivity extends AppCompatActivity implements MainContact.view {
    private AppDatabase appDatabase;
    private MainPresenter mainPresenter;
    private MainAdapter mainAdapter;

    private Button btn_submit;
    private RecyclerView recyclerView;
    private EditText et_fullname, et_username, et_phonenumber, et_email;
    private int id = 0;
    boolean edit = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_submit = findViewById(R.id.btn_submit);
        et_fullname = findViewById(R.id.et_fullname);
        et_username = findViewById(R.id.et_username);
        et_phonenumber = findViewById(R.id.et_phonenumber);
        et_email = findViewById(R.id.et_email);
        recyclerView = findViewById(R.id.recyclerview);

        appDatabase = AppDatabase.inidb(getApplicationContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        mainPresenter = new MainPresenter(this);
        mainPresenter.readData(appDatabase);
        btn_submit.setOnClickListener(this);
    }

    @Override
    public void successAdd() {
        Toast.makeText(this,"Success!", Toast.LENGTH_SHORT).show();
        mainPresenter.readData(appDatabase);
    }

    @Override
    public void successDelete() {
        Toast.makeText(this,"Data was successfully deleted!",Toast.LENGTH_SHORT).show();
        mainPresenter.readData(appDatabase);
    }

    @Override
    public void resetForm() {
        et_fullname.setText("");
        et_username.setText("");
        et_phonenumber.setText("");
        et_email.setText("");
        btn_submit.setText("Submit");
    }

    public void getData(List<DataMember> list){
        mainAdapter = new MainAdapter(this,list,this);
        recyclerView.setAdapter(mainAdapter);
    }

    public void editData(DataMember item){
        et_fullname.setText(item.getFullname());
        et_username.setText(item.getUsername());
        et_phonenumber.setText(item.getPhone_number());
        et_email.setText(item.getEmail());
        id = item.getId();
        edit = true;
        btn_submit.setText("EDIT DATA");
    }

    @Override
    public void deleteData(DataMember item) {
        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.N){
            builder = new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
        } else {
            builder = new AlertDialog.Builder(this);
        }
        builder.setTitle("DELETE DATA")
                .setMessage("Are you sure want to delete?")
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        resetForm();
                        mainPresenter.deleteData(item,appDatabase);
                    }
                })
                .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                })
                .setIcon(android.R.drawable.ic_menu_delete)
                .show();
    }

    public  void onClick(View view) {
        if (view.getId() == R.id.btn_submit) {
            if (et_fullname.getText().toString().equals("") || et_username.getText().toString().equals("") ||
                    et_phonenumber.getText().toString().equals("") || et_email.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Harap isi Semua data", Toast.LENGTH_SHORT).show();
            } else {
                if (!edit) {
                    mainPresenter.insertData(et_fullname.getText().toString(), et_username.getText().toString(), et_phonenumber.getText().toString(),
                            et_email.getText().toString(), appDatabase);
                } else {
                    mainPresenter.editData(et_fullname.getText().toString(), et_username.getText().toString(), et_phonenumber.getText().toString(),
                            et_email.getText().toString(), id, appDatabase);
                    edit = false;
                }
                resetForm();
            }
        }
    }
}