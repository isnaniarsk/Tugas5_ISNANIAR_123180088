package com.example.tugas5.view;

import android.view.View;

import com.example.tugas5.entity.AppDatabase;
import com.example.tugas5.entity.DataMember;

import java.util.List;

public interface MainContact {
    interface view extends View.OnClickListener{
        void successAdd();
        void successDelete();
        void resetForm();
        void getData(List<DataMember> list);
        void editData(DataMember item);
        void deleteData(DataMember item);
    }

    interface presenter{
        void insertData(String fullname, String username, String phone_number, String email, AppDatabase database);
        void readData(AppDatabase database);
        void editData(String fullname, String username, String phone_number, String email, int id, AppDatabase database);
        void deleteData(DataMember dataMember, AppDatabase appDatabase);
    }
}
