package com.example.tugas5.view;

import android.os.AsyncTask;
import android.util.Log;

import com.example.tugas5.entity.AppDatabase;
import com.example.tugas5.entity.DataMember;

import java.util.List;

public class MainPresenter implements MainContact.presenter {
    private MainContact.view view;

    public MainPresenter(MainContact.view view){
        this.view = view;
    }

    class InsertData extends AsyncTask<Void,Void,Long> {
        private AppDatabase appDatabase;
        private DataMember dataMember;
        public InsertData(AppDatabase appDatabase, DataMember dataMember) {
            this.appDatabase = appDatabase;
            this.dataMember = dataMember;
        }

        protected Long doInBackground(Void... voids){
            return appDatabase.dao().insertData(dataMember);
        }

        protected void onPostExecute(Long along){
            super.onPostExecute(along);
            view.successAdd();
        }
    }

    @Override
    public void insertData(String fullname, String username, String phone_number, String email, AppDatabase database) {
        final DataMember dataMember =  new DataMember();
        dataMember.setFullname(fullname);
        dataMember.setUsername(username);
        dataMember.setPhone_number(phone_number);
        dataMember.setEmail(email);
        new InsertData(database,dataMember).execute();
    }

    @Override
    public void readData(AppDatabase database) {
        List<DataMember> list;
        list = database.dao().getData();
        view.getData(list);
    }

    class EditData extends AsyncTask<Void, Void, Integer> {
        private AppDatabase appDatabase;
        private DataMember dataMember;

        public EditData(AppDatabase appDatabase, DataMember dataMember){
            this.appDatabase = appDatabase;
            this.dataMember = dataMember;
        }

        protected Integer doInBackground(Void... voids){
            return  appDatabase.dao().updateData(dataMember);
        }

        protected void  onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            Log.d("integer db", "onPostExecute : "+integer);
            view.successAdd();
        }
    }

    @Override
    public void editData(String fullname, String username, String phone_number, String email, int id, AppDatabase database) {
        final DataMember dataMember = new DataMember();
        dataMember.setFullname(fullname);
        dataMember.setUsername(username);
        dataMember.setPhone_number(phone_number);
        dataMember.setEmail(email);
        dataMember.setId(id);
        new EditData(database,dataMember).execute();
    }

    class  DeleteData extends  AsyncTask<Void,Void,Long>{
        private AppDatabase appDatabase;
        private DataMember dataMember;

        public DeleteData(AppDatabase appDatabase, DataMember dataMember){
            this.appDatabase = appDatabase;
            this.dataMember = dataMember;
        }

        protected Long doInBackground(Void... voids){
            appDatabase.dao().deleteData(dataMember);
            return null;
        }

        protected void  onPostExecute(Long along) {
            super.onPostExecute(along);
            view.successDelete();
        }
    }

    @Override
    public void deleteData(DataMember dataMember, AppDatabase appDatabase) {
        new DeleteData(appDatabase, dataMember).execute();
    }
}
